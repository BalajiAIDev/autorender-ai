# YOLO detection routes
