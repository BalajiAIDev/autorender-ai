# Loads YOLO, Stable Diffusion, SmartCrop models
