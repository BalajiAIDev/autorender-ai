# YOLO detection logic
